package com.tutorial.bikeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BikeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
